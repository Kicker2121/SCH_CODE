/* Name:
 * Date:
 * Class: CSC-1710 Fall 2014
 * Location: 
 *
 * This is an image filter program.  Currently, it only performs one filter.
 * 1) filters a color image into a black and white image.
 *
 */
#include<stdlib.h>
#include<stdio.h>


int main()
{
   image_t orig_image; 
   image_t new_image; 

   read_image(stdin,&orig_image);

   //to test your write_image and write_pixel
   //place call to cvt_to_bw on next line 
  

   write_image(stdout,&new_image);

   return 0;
}
