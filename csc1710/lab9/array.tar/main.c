/*
 * Name: Alex Sims
 * Date: March 27, 2015
 * Class: CSC1710
 * Location: csc1710/lab9/
 */
#include<stdio.h>
#include"arraylib.h"
void inner_product (int a[], int b[], int count)
int main (void)
{
   int a[] = {4, 3, 7, 2};
   int b[] = {2, 7, 3, 4};
   int count = 4;
   int product;

   fscanf(stdin, "%c", &a[count];
}
   for( i = 0; i < count-1; i++) {
   product += a[4]
   }

   printf("The sum of the inner product is: %c", int a[], int b[], int count); 
   printf("The reverse of the array is: ", int [a], int count);

   return 0;
}   
