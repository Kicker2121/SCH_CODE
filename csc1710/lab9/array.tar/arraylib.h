/* Name: Alex Sims
 * Date: March 27, 2015
 * Class: CSC1710
 * Location: csc1710/lab9/
 */

//Prototpye for both functions//
int inner_product(int a[], int b[], int count)
void reverse( int a[], int count)

