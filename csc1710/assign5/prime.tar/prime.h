/*
 * Name: Alex Sims
 * Date: 4 / 9 / 15
 * Location: ~/csc1710/assign5/prime.h
 * Comment: This program is to ouytput prime numbers given by the user from the number 2 to a number, by of which is inputed between 1 and 1000. By outputing certain Pr * ime Numbers based on a column format of 5 prime numbers, with increased value within each row.
 */

void prime_search (bool P[], int i, int n);
void prime_print (bool P[], int i, int n);
void lines (int count);
void remove_nonPrime (bool P[], int i, int n);
